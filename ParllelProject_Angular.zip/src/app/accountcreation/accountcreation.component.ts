import { Component, OnInit } from '@angular/core';
import data from '../../data/accountdetails.json';
@Component({
  selector: 'app-accountcreation',
  templateUrl: './accountcreation.component.html',
  styleUrls: ['./accountcreation.component.css']
})
export class AccountcreationComponent implements OnInit {
  array=data
  accNum: number;
  successflag=false
  constructor() { }

  ngOnInit() {
  }
  add(form)
  {
    this.accNum=Math.floor(Math.random() * 100) + 1 
    this.array.push({
      accNum: this.accNum, 
      name: form.name, 
      phone: form.phone, 
      email: form.email, 
      balance: 0})
    this.successflag=true;
  }
}
